export const BASIC_DATA_SYS = {
    // 机构类型
    organTypeId: '0aa0c2d07e14275cc51b65e82fa1e656',
    // 机构性质
    organNature: 'c0fc1a801dca3a64bf9a90c09ee3b5e6',
    // 职权取得方式
    accessToAuthority: '781d38e8833c01989fc644f996364a83',
    // 归档环节id\表单类型id
    archiveId:'2c9029ee6cac9281016cacab478e0007',
    // 证据类型
    enTypeId: '574a5a05d004e32fe5d7f73c4b6a22ef'
}
