<template>
  <div class="handlePart caseHandleSearchPart">
    <div v-if="caseState == 'transfer'">
      <el-button type="primary" size="medium" icon="el-icon-plus" @click="newAdd">新增移送</el-button>
    </div>
    <div>
      <el-form :model="caseSearchForm" ref="caseSearchForm" class="caseSearchForm" label-width="100px">
        <div :class="lineSearchSty">
          <div class="item" v-if="caseState == 'transfer'">
            <el-form-item label="案号">
              <el-input v-model="caseSearchForm.caseNumber"></el-input>
            </el-form-item>
          </div>

          <div class="item">
            <el-form-item label="当事人/单位">
              <el-input v-model="caseSearchForm.party"></el-input>
            </el-form-item>
          </div>
          <div class="item">
            <el-form-item label="目标机构">
              <el-input v-model="caseSearchForm.organMb"></el-input>
            </el-form-item>
          </div>
          <div class="item">
            <el-form-item label="处理状态">
              <!-- <el-input v-model="caseSearchForm.caseStatus"></el-input> -->
              <el-select v-model="caseSearchForm.caseType" placeholder="全部">
                <el-option v-for="item in caseStateList" :key="item.id" :label="item.name" :value="item.name"></el-option>
              </el-select>
            </el-form-item>
          </div>
          <div class="item">&nbsp;
            <el-button type="primary" size="medium" icon="el-icon-search" @click="searchCaseEmit"></el-button>
            <el-button type size="medium" :icon="hideSomeSearch ? 'el-icon-arrow-down':'el-icon-arrow-up'" @click="showSomeSearchEmit"></el-button>
          </div>
        </div>
        <div :class="{hideSomeSearchClass:hideSomeSearch,lineTwoStyle:caseState == 'waitArchive'}">
          <div class="item">
            <el-form-item label="违法行为">
              <el-input v-model="caseSearchForm.wfxw"></el-input>
            </el-form-item>
          </div>
          <div class="item">
            <el-form-item label="申请人">
              <el-input v-model="caseSearchForm.person"></el-input>
            </el-form-item>
          </div>

          <div class="item">
            <el-form-item label="发起时间">
              <el-date-picker v-model="caseSearchForm.time" type="daterange" range-separator="-" start-placeholder="开始日期" end-placeholder="结束日期" value-format="yyyy-MM-dd HH:mm:ss" format="yyyy-MM-dd" :default-time="['00:00:00', '23:59:59']">
              </el-date-picker>
            </el-form-item>
          </div>
        </div>
      </el-form>
    </div>
  </div>
</template>
<script>
import {
  getQueryLinkListApi,
  getQueryCaseTypeListApi,
} from "@/api/caseHandle";
import {
  getDictListDetailApi
} from "@/api/system";
export default {
  data() {
    return {
      caseSearchForm: {
        caseNumber: "",
        person: '',
        time: '',
        party: "",
        organMb: "",
        wfxw: "",
      },
      hideSomeSearch: true,
      linkList: [], //环节
      caseTypeList: [],//类型
      caseStateList: [],//状态
      dictId: this.caseState == "waitDeal" ? "ef38274ddea12be26e9a8c1bf23cd401" : "324701f1633dd65ca79a28fbc79c1628",
    };
  },
  computed: {
    lineSearchSty() {
      if (this.caseState == "transfer") {
        return "unRecordCaseStyle";
      } else if (this.caseState == "waitDeal") {
        return "waitDealStyle";
      } else if (this.caseState == "approveIng") {
        return "approveIngStyle";
      }
    }
  },
  props: ["caseState"],
  methods: {
    caseRecord() { },
    //展开
    showSomeSearchEmit() {
      this.$emit("showSomeSearch");
      this.hideSomeSearch = !this.hideSomeSearch;
    },
    newAdd() {
      //   this.$emit("caseRecord");
      this.$router.push({
        name: 'addSelect',
        params: {
          fromSlide: true
        }
      })
    },
    //查询所以环节
    getAllLinkList() {
      getQueryLinkListApi().then(
        res => {
          this.linkList = res.data;
        },
        error => {
          console.log(error)
        }
      );
    },
    //查询所有案件类型
    getQueryCaseTypeList() {
      getQueryCaseTypeListApi().then(
        res => {
          console.log('类型', res);
          this.caseTypeList = res.data.records;
        },
        error => {
          console.log(error)
        }
      );
    },
    //搜索
    searchCaseEmit() {
      console.log('点击')
      this.caseSearchForm.records = JSON.stringify(this.caseSearchForm.records)
      this.$emit('searchCase', this.caseSearchForm);
    },
    //查询案件状态
    getQueryCaseStateList() {
      getDictListDetailApi(this.dictId).then(
        res => {
          console.log("状态", res);
          // this.options = res.data;
          this.caseStateList = res.data;
        },
        err => {
          console.log(err);
        }
      );
    }
  },
  created() {
    this.getAllLinkList();
    this.getQueryCaseTypeList();
    this.getQueryCaseStateList();
  }
};
</script>
