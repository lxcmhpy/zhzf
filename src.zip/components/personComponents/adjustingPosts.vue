<template>
  <div>
    <div>
      <div style="margin-top:35px;margin-bottom:25px;margin-left:25px;">
        <font style="font-size:25px;"><span class="titleflag"></span>调动信息</font> 
      </div>
      <el-table
        style="margin-left:25px; width:97%;margin-bottom:35px;"
        :data="tableData"
        resizable
        stripe>
        <el-table-column prop="date" label="转出单位"></el-table-column>
        <el-table-column prop="name" label="转出时间"></el-table-column>
        <el-table-column prop="address" label="转出执法门类"></el-table-column>
        <el-table-column prop="address" label="执法证号"></el-table-column>
        <el-table-column prop="address" label="转入单位"></el-table-column>
        <el-table-column prop="address" label="转入时间"></el-table-column>
        <el-table-column prop="address" label="转入执法门类"></el-table-column>
        <el-table-column prop="address" label="调岗状态"></el-table-column>
        <el-table-column prop="address" label="操作人"></el-table-column>
        <el-table-column prop="address" label="操作时间"></el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
    export default {
        name: "adjustingPosts",//调岗组件
        data(){
          return {
            tableData: [],
            currentPage: 1, //当前页
            pageSize: 20,   //pagesize
          }
        },
        methods:{
          getAdjustingPostsInfo(){
            let paramsData={
              current: this.currentPage,
              size: this.pageSize,
              personId: this.$route.params.personInfo.personId,
            }
            let _this = this
            this.$store.dispatch("getTransferListMoudle",paramsData).then(res=>{
                  _this.tableData = res.data.records;
            });
            error=>{
              console.info(error);
            };
          }
        },
        created(){
          this.getAdjustingPostsInfo();
        }
    }
</script>

<style lang="scss" scoped>
  @import "@/assets/css/personManage.scss";
  .titleflag {
                width      : 4px;
                height     : 22px;
                margin-right: 8px;
                display    : inline-block;
                background : #4573D0;
            }
</style>
