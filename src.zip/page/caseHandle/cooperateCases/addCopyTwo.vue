<template>
  <div class="add_dialog">
    <div class="add_dialog_content">
      <div class="step_content">
        <el-steps :active="1" finish-status="success" class="steps">
          <el-step title="选择案件"></el-step>
          <el-step title="抄告详情"></el-step>
        </el-steps>
      </div>
      <div class="border_blue"></div>
      <el-form :model="caseData" :rules="rules" ref="caseData" label-width="100px" class="demo-ruleForm">
        <div class="content_bg">
          <el-form-item label="案号">
            {{caseData.caseNumber}}
            <el-button class="re_select" size="small" @click="reSelect" plain>重新选择</el-button>
          </el-form-item>
          <el-form-item label="案由">
            {{caseData.party}}{{caseData.caseCauseName}}
          </el-form-item>
        </div>
        <el-form-item label="目标机构" class="is-required">
          <el-row :gutter="20">
            <el-col :span="5">
              <el-form-item prop="organType">
                <el-select v-model="caseData.organType" placeholder="机构类型">
                  <el-option label="执法机构" value="执法机构"></el-option>
                  <el-option label="公安机关" value="公安机关"></el-option>
                  <el-option label="司法机关" value="司法机关"></el-option>
                  <el-option label="其他部门" value="其他部门"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="17">
              <el-form-item prop="organMb">
                <el-input v-model="caseData.organMb" :disabled=" caseData.organType ? false : true "></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form-item>
        <el-form-item label="抄告原因" prop="copyReason">
          <el-input v-model="caseData.copyReason"></el-input>
        </el-form-item>
        <el-form-item label="附件">
          <!-- appendix -->
          <el-upload class="upload-demo" action="https://jsonplaceholder.typicode.com/posts/" :http-request="uploadPaymentVoucher" :show-file-list="false">
            <el-button size="small" type="primary">选取文件</el-button>
          </el-upload>
          <ul>
            <li v-for="item in fileListArr" :key="item.id">{{item.fileName}}
              <span ><i @click="deleteFile(item)" class="el-icon-circle-close"></i></span>
            </li>
          </ul>
        </el-form-item>
        <el-form-item label="备注">
          <el-input type="textarea" v-model="caseData.notes"></el-input>
        </el-form-item>
        <center>
          <el-button type="primary" @click="submitForm('caseData')" style="width:174px;margin-bottom:74px;margin-top:70px">提交</el-button>
        </center>
      </el-form>
    </div>

  </div>
</template>
<script>
import { addEditCopyCaseApi} from "@/api/caseHandle";
import iLocalStroage from "@/common/js/localStroage";
import { uploadEvApi, findFileByIdApi ,deleteFileByIdApi ,getFile } from "@/api/upload";
export default {
  data() {
    return {
      caseData: {
        person: '',
        caseNumber: '',
        caseCauseName: '',
        organSend: '',
        organType: '',
        organMb: '',
        appendix: '',
        copyReason: '',
        notes: '',
        party: '',
        state: '',
        createTime: new Date()
      },
      fileListArr: [], //已上传的附件
      rules: {
        organType: [
          { required: true, message: '请选择机构类型', trigger: 'blur' }
        ],
        organMb: [
          { required: true, message: '请输入目标机构', trigger: 'blur' }
        ],
        copyReason: [
          { required: true,max: 10, message: '请选择抄告原因,且最多10个汉字', trigger: 'blur' }
        ]
      }
    };
  },
  methods: {
    reSelect() {
      this.$store.dispatch("deleteTabs", this.$route.name);
      this.$router.replace({
        name: "addCopyOne",
      });
    },
    submitForm(formName) {
      let appendixList= []
      this.fileListArr.forEach(element => {
        appendixList.push(element.fileName)
      });
      this.caseData.appendix=appendixList.join(',')
      if(this.caseData.organType == "执法机构"){
        this.caseData.state = "1";
      }else{
        this.caseData.state = "2";
      }
      this.$refs[formName].validate((valid) => {
        if (valid) {
          console.log("添加",this.caseData)
          addEditCopyCaseApi(this.caseData).then(res => {
            console.log(res);
            if (res.code == 200) {
              this.$store.dispatch("deleteTabs", this.$route.name);
              this.$router.replace({
                name: "copyCase"
              });
            }
          }, err => {
            console.log(err);
          })
        } else {
          this.$message({
            type: "error",
            message: "请完善表单信息"
          });
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    //上传附件
    uploadPaymentVoucher(param) {
      const isLt2M = param.file.size / 1024 / 1024 < 10     //这里做文件大小限制
      if(this.fileListArr.length >=3){
        this.$message.warning('最多选择3个文件！');
        return;
      }
      if(!isLt2M) {
        this.$message({
          message: '上传文件大小不能超过 10MB!',
          type: 'warning'
        });
        return;
      }
      for(let i=0; i<this.fileListArr.length; i++){
        if(param.file.name == this.fileListArr[i].fileName){
          this.$message.warning('不能上传同一个文件');
          return;
        }
      }
      var fd = new FormData()
      fd.append("file", param.file);
      fd.append('caseId', this.caseData.caseId)
      fd.append('docId', '2c9029e16c753a19016c755fe1340001');
      uploadEvApi(fd).then(
        res => {
          console.log(res);
          this.findFileList(res.data, true);
        },
        error => {
          console.log(error)
        }
      );
    },
    //删除附件
    deleteFile(data){
      console.log('删除',data);
      deleteFileByIdApi(data.storageId).then(res=>{
        console.log(res);
        this.findFileList();
      },err=>{
         console.log(err)
      })
    },
    //  //通过附件id 查询附件file
    // findPaymentVoucher(id, isAdd) {
    //   findFileByIdApi(id).then(
    //     res => {
    //       console.log(res);
    //       this.fileListArr.push(res.data);
    //     },
    //     error => {
    //       console.log(error)
    //     }
    //   );
    // }
     //通过案件ID和文书ID查询附件
    findFileList(){
      let data =  {
        caseId: this.caseData.caseId,
        docId :"2c9029e16c753a19016c755fe1340001"
      }
      console.log(data);
      getFile(data).then(
        res => {
          console.log("附件列表",res);
          this.fileListArr = res.data;

        },
        error => {
          console.log(error);
        }
      )
    },
  },
  mounted() {
    console.log('选择的案件', this.$route.params)
    let datas = this.$route.params.caseData;
    let caseData = this.caseData;
    console.log('用户信息', iLocalStroage.gets("userInfo"))
    for (var key in caseData) {
      if(key != 'state')
      this.caseData[key] = datas[key]
    }
    this.caseData.caseId = this.$route.params.caseData.id
    this.caseData.person = iLocalStroage.gets("userInfo").username
    this.caseData.organSend = iLocalStroage.gets("userInfo").organName
    console.log('表单', this.caseData)
  },
  created(){
    this.findFileList();
  }
}
</script>
<style lang="scss" scoped>
/* @import "@/assets/css/caseHandle/index.scss"; */
@import "@/assets/css/documentForm.scss";
</style>
 
<style scoped>
.steps /deep/ .el-step__icon {
  font-size: 18px;
  width: 42px !important;
  height: 42px;
}
.steps /deep/ .is-process /deep/.el-step__icon {
  background: #4573d0;
  color: #ffffff;
  border-color: #4573d0;
}
.steps /deep/ .el-step__head.is-success {
  color: #4573d0;
  border-color: #4573d0;
}
.steps /deep/ .el-step__title.is-success {
  color: #b2b2b2;
}
.steps /deep/ .el-step__icon /deep/.el-step__icon-inner {
  font-weight: 400;
}
.steps /deep/ .el-step__main {
  white-space: normal;
  text-align: left;
  margin-top: -42px;
  margin-left: 42px;
  padding-left: 11px;
  width: 66px;
  z-index: 1;
  position: relative;
}
.steps /deep/ .el-step.is-horizontal .el-step__line {
  height: 2px;
  top: 21px;
  left: 128px;
  right: 26px;
}
.list /deep/ .el-checkbox__input {
  vertical-align: middle;
  position: absolute;
  top: 3px;
}

.list /deep/ .el-checkbox__label {
  width: calc(100% - 22px);
  padding-left: 22px;
  line-height: 20px;
  font-size: 14px;
  color: #20232b;
  font-weight: 600;
}
</style>
