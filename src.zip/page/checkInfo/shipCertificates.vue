<template>
    <div>
        船舶营运证
    </div>
</template>