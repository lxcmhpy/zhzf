<template>
    <div>客运线路标志牌</div>
</template>