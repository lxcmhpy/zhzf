<template>
    <div>
        <span>{{ DateList }}</span>
    </div>
</template>
<script>
export default {
    data(){
        return{
            DateList:'证件数据',
        }
    }
}

</script>
<style lang="scss">
@import "@/assets/css/personManage.scss";
</style>
