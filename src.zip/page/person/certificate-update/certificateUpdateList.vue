<template>
    <div>
        <span>{{ verificationupdate }}</span>
    </div>
</template>
<script>
export default {
    data(){
        return{
            verificationupdate:'验证修改',
        }
    }
}

</script>
<style lang="scss">
  @import "@/assets/css/personManage.scss";
</style>
