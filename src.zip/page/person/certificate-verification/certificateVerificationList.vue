<template>
    <div>
        <span>{{ verificationDate }}</span>
    </div>
</template>
<script>
export default {
    data(){
        return{
            verificationDate:'验证证件',
        }
    }
}

</script>
<style lang="scss">
@import "@/assets/css/personManage.scss";
</style>
