<template>
  <div >
     wenwenwnenwne
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
  methods: {
     
  }
};
</script>
