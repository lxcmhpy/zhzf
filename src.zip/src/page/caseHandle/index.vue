<template>
    <div>案件办理</div>
</template>
<script>
export default {
    data() {
        return{
            
        }
    },
    methods:{

    }
}
</script>