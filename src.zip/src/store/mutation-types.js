//common
export const COM_LOADING_STATUS = "COM_LOADING_STATUS";
export const COM_LOADINGTIME = "COM_LOADINGTIME";
export const SET_AUTHTOKEN = "SET_AUTHTOKEN";

export const SET_SLIDEMENU = "SET_SLIDEMENU";
export const ADD_TABS = "ADD_TABS";
export const DELETE_TABS = "DELETE_TABS";
export const DELETE_ALLTABS = "DELETE_ALLTABS";
export const SET_ACTIVE_INDEX = "SET_ACTIVE_INDEX";

export const USERNAME = "USERNAME";

export const SET_IMGSRC = "SET_IMGSRC";

export const SET_WHITELIST = "SET_WHITELIST";
export const EDIT_WHITELIST = "EDIT_WHITELIST";
export const RESET_WHITELIST = "RESET_WHITELIST";

export const SET_APIHISTORYLIST = "SET_APIHISTORYLIST";

export const SET_LISTPAGE = "SET_LISTPAGE";
